from pathlib import Path
import utils
from setup import get_credentials
from siri import Siri

if __name__ == "__main__":
    project_root = Path(__file__).parent
    log_file = utils.get_log_file_for_today(project_root)
    groq_key, google_key, openai_key = get_credentials()
    assistant = Siri(log_file, project_root, groq_key, google_key, openai_key)
    assistant.listen()
