import os
from datetime import datetime
from pathlib import Path
import pyperclip
from PIL import ImageGrab

def get_log_file_for_today(project_root_folder_path: Path) -> Path:
    today = datetime.today()
    year = today.strftime("%Y")
    month = today.strftime("%m")
    day = today.strftime("%d")

    base_folder = os.path.join(
        project_root_folder_path, "data", "chat_history", year, month
    )
    os.makedirs(base_folder, exist_ok=True)
    chat_log_file = os.path.join(base_folder, f"{day}.log")
    Path(chat_log_file).touch(exist_ok=True)
    return Path(os.path.abspath(chat_log_file))

def log_chat_message(log_file_path: Path, user_message=None, ai_message=None):
    with open(log_file_path, "a", encoding="utf-8") as f:
        if user_message:
            f.write(f"USER: {user_message}\n")
        if ai_message:
            f.write(f"AI: {ai_message}\n")

def get_path_to_folder(folder_type: str) -> Path:
    base_path = Path(os.path.join(Path.home(), "Pictures", "llama3.1"))
    folder_map = {
        "screenshot": Path(os.path.join(base_path, "Screenshots")),
        "webcam": Path(os.path.join(base_path, "Webcam")),
    }
    return folder_map[folder_type]

def capture_screenshot() -> Path:
    folder = get_path_to_folder("screenshot")
    os.makedirs(folder, exist_ok=True)
    screen = ImageGrab.grab()
    timestamp = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
    path = folder / f"screenshot_{timestamp}.png"
    screen.save(path, quality=20)
    return path

def remove_last_screenshot():
    folder = get_path_to_folder("screenshot")
    files = [f for f in folder.iterdir() if f.is_file() and f.suffix==".png"]
    if files:
        latest = max(files, key=lambda f: f.stat().st_ctime)
        latest.unlink()

def get_clipboard_text() -> str:
    content = pyperclip.paste()
    return content if isinstance(content, str) else ""
