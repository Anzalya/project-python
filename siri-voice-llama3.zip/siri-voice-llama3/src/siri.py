import time
from pathlib import Path
import pyttsx3
import speech_recognition as sr
from faster_whisper import WhisperModel
from groq import Groq
import google.generativeai as genai
import webcam
import utils
from gtts import gTTS
from pydub import AudioSegment
from pydub.playback import play

class Siri:
    def __init__(self, log_file_path: Path, project_root: Path, groq_key, google_key, openai_key=None):
        self.log_file_path = log_file_path
        self.project_root = project_root
        self.pyttsx3_engine = pyttsx3.init()
        self.groq_client = Groq(api_key=groq_key)
        genai.configure(api_key=google_key)
        self.audio_model = WhisperModel("base")
        self.speech_recognizer = sr.Recognizer()
        self.mic = sr.Microphone()
        self.wake_word = "siri"
        self.conversation = [{"role":"system","content":"You are a helpful assistant"}]

    def transcribe(self, audio_path: Path):
        segments,_ = self.audio_model.transcribe(str(audio_path))
        return "".join(seg.text for seg in segments)

    def speak(self, text: str):
        self.pyttsx3_engine.say(text)
        self.pyttsx3_engine.runAndWait()

    def generate_response(self, prompt: str, image_context=None):
        full_prompt = f"{prompt}\nIMAGE_CONTEXT:{image_context}" if image_context else prompt
        self.conversation.append({"role":"user","content":full_prompt})
        resp = self.groq_client.chat.completions.create(model="llama-3.1-8b-instant", messages=self.conversation)
        ai = resp.choices[0].message.content
        self.conversation.append({"role":"assistant","content":ai})
        return ai or "I don't know"

    def listen(self):
        with self.mic as source:
            self.speech_recognizer.adjust_for_ambient_noise(source, duration=2)

        def callback(recognizer, audio):
            tmp = Path(self.project_root) / "tmp.wav"
            with open(tmp, "wb") as f:
                f.write(audio.get_wav_data())
            text = self.transcribe(tmp)
            if self.wake_word in text.lower():
                prompt = text.lower().replace(self.wake_word, "").strip()
                utils.log_chat_message(self.log_file_path, user_message=prompt)
                resp = self.generate_response(prompt)
                utils.log_chat_message(self.log_file_path, ai_message=resp)
                self.speak(resp)
            tmp.unlink()

        self.speech_recognizer.listen_in_background(self.mic, callback)
        while True: time.sleep(0.5)
