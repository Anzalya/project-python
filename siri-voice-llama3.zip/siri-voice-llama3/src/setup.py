import os
from dotenv import load_dotenv
import utils

load_dotenv()

def get_credentials():
    groq_key = os.getenv("GROQ_API_KEY")
    google_key = os.getenv("GOOGLE_GENERATIVE_AI_API_KEY")
    openai_key = os.getenv("OPENAI_API_KEY")
    if not groq_key or not google_key:
        raise ValueError("GROQ or Google API key missing in .env")
    return groq_key, google_key, openai_key
