import cv2
import os
from datetime import datetime
from pathlib import Path
import utils

def get_webcam():
    for i in range(10):
        cam = cv2.VideoCapture(i)
        if cam.isOpened():
            return cam
    raise RuntimeError("No webcam found")

def capture_webcam_image() -> Path:
    cam = get_webcam()
    folder = utils.get_path_to_folder("webcam")
    os.makedirs(folder, exist_ok=True)
    timestamp = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
    path = folder / f"webcam_{timestamp}.png"
    _, frame = cam.read()
    cv2.imwrite(str(path), frame)
    cam.release()
    return path
