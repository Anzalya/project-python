from collections import OrderedDict, deque
import numpy as np
import math

class CentroidTracker:
    def __init__(self, max_disappeared=50, max_distance=50, buffer_size=30):
        self.next_object_id = 0
        self.objects = OrderedDict()
        self.disappeared = OrderedDict()
        self.centroid_history = OrderedDict()

        self.max_disappeared = max_disappeared
        self.max_distance = max_distance
        self.buffer_size = buffer_size

    def register(self, centroid):
        oid = self.next_object_id
        self.objects[oid] = centroid
        self.disappeared[oid] = 0
        self.centroid_history[oid] = deque([centroid], maxlen=self.buffer_size)
        self.next_object_id += 1
        return oid

    def deregister(self, object_id):
        if object_id in self.objects:
            del self.objects[object_id]
        if object_id in self.disappeared:
            del self.disappeared[object_id]
        if object_id in self.centroid_history:
            del self.centroid_history[object_id]

    def update(self, rects):
        if len(rects) == 0:
            for oid in list(self.disappeared.keys()):
                self.disappeared[oid] += 1
                if self.disappeared[oid] > self.max_disappeared:
                    self.deregister(oid)
            return self.objects

        input_centroids = np.zeros((len(rects), 2), dtype="int")
        for (i, (startX, startY, endX, endY)) in enumerate(rects):
            cX = int((startX + endX) / 2.0)
            cY = int((startY + endY) / 2.0)
            input_centroids[i] = (cX, cY)

        if len(self.objects) == 0:
            for i in range(0, len(input_centroids)):
                self.register(tuple(input_centroids[i]))
        else:
            object_ids = list(self.objects.keys())
            object_centroids = list(self.objects.values())

            D = np.zeros((len(object_centroids), len(input_centroids)), dtype="float")
            for i in range(len(object_centroids)):
                for j in range(len(input_centroids)):
                    D[i, j] = math.hypot(
                        object_centroids[i][0] - input_centroids[j][0],
                        object_centroids[i][1] - input_centroids[j][1]
                    )

            rows = D.min(axis=1).argsort()
            cols = D.argmin(axis=1)[rows]

            assigned_rows = set()
            assigned_cols = set()

            for (row, col) in zip(rows, cols):
                if row in assigned_rows or col in assigned_cols:
                    continue
                if D[row, col] > self.max_distance:
                    continue

                oid = object_ids[row]
                self.objects[oid] = tuple(input_centroids[col])
                self.disappeared[oid] = 0
                self.centroid_history[oid].append(tuple(input_centroids[col]))

                assigned_rows.add(row)
                assigned_cols.add(col)

            unassigned_rows = set(range(0, D.shape[0])) - assigned_rows
            for row in unassigned_rows:
                oid = object_ids[row]
                self.disappeared[oid] += 1
                if self.disappeared[oid] > self.max_disappeared:
                    self.deregister(oid)

            unassigned_cols = set(range(0, D.shape[1])) - assigned_cols
            for col in unassigned_cols:
                self.register(tuple(input_centroids[col]))

        return self.objects

    def get_history(self, object_id):
        return list(self.centroid_history.get(object_id, []))
