import cv2
import numpy as np
from ultralytics import YOLO
from centroid_tracker import CentroidTracker

# ---------- НАСТРОЙКИ ----------
SOURCE = 0
MODEL_NAME = "yolov8n.pt"
TARGET_CLASSES = None
CONFIDENCE_THRESHOLD = 0.3
LINE_POSITION = 0.5
DIRECTION = "down"
MAX_DISAPPEARED = 40
MAX_DISTANCE = 70
# --------------------------------

def filter_boxes_by_classes(results, model, classes_target):
    boxes = []
    names = []
    if results.boxes is None:
        return boxes, names

    for box in results.boxes:
        conf = float(box.conf[0])
        if conf < CONFIDENCE_THRESHOLD:
            continue

        cls_idx = int(box.cls[0])
        cls_name = model.names[cls_idx]

        accept = False
        if classes_target is None:
            accept = True
        else:
            if all(isinstance(x, str) for x in classes_target):
                if cls_name in classes_target:
                    accept = True
            else:
                if cls_idx in classes_target:
                    accept = True

        if accept:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            boxes.append((x1, y1, x2, y2))
            names.append(cls_name)

    return boxes, names

def main():
    print("[INFO] Loading model...")
    model = YOLO(MODEL_NAME)

    print(f"[INFO] Opening source: {SOURCE}")
    cap = cv2.VideoCapture(SOURCE)

    if not cap.isOpened():
        print("[ERROR] Could not open video source.")
        return

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    line_y = int(height * LINE_POSITION)

    tracker = CentroidTracker(
        max_disappeared=MAX_DISAPPEARED,
        max_distance=MAX_DISTANCE
    )

    counted_ids = set()
    total_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        results = model(frame)[0]
        boxes, names = filter_boxes_by_classes(results, model, TARGET_CLASSES)
        objects = tracker.update(boxes)

        cv2.line(frame, (0, line_y), (width, line_y), (0, 0, 255), 2)

        centroid_to_box = {}
        for i, (x1, y1, x2, y2) in enumerate(boxes):
            cX = int((x1 + x2) / 2.0)
            cY = int((y1 + y2) / 2.0)
            centroid_to_box[(cX, cY)] = i

        for oid, (cX, cY) in objects.items():
            if (cX, cY) in centroid_to_box:
                bi = centroid_to_box[(cX, cY)]
                x1, y1, x2, y2 = boxes[bi]
                cls_name = names[bi]

                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, cls_name, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            cv2.circle(frame, (cX, cY), 4, (255, 0, 0), -1)
            cv2.putText(frame, f"ID {oid}", (cX - 10, cY - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

            history = tracker.get_history(oid)
            if len(history) >= 2 and oid not in counted_ids:
                prev_y = history[-2][1]
                curr_y = history[-1][1]

                if DIRECTION == "down" and prev_y < line_y <= curr_y:
                    total_count += 1
                    counted_ids.add(oid)

                elif DIRECTION == "up" and prev_y > line_y >= curr_y:
                    total_count += 1
                    counted_ids.add(oid)

                elif DIRECTION == "both":
                    if (prev_y < line_y <= curr_y) or (prev_y > line_y >= curr_y):
                        total_count += 1
                        counted_ids.add(oid)

        cv2.putText(frame, f"COUNT: {total_count}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 255), 2)

        cv2.imshow("Counter Vision", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()
    print(f"[INFO] Final count: {total_count}")

if __name__ == "__main__":
    main()
