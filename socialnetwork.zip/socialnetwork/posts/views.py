from django.shortcuts import render, redirect
from .models import Post, Like

def create_post(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        body = request.POST.get('body')
        Post.objects.create(author=request.user, title=title, body=body)
        return redirect('create_post')
    posts = Post.objects.all().order_by('-created_at')
    return render(request, 'posts/create_post.html', {'posts': posts})

def like_post(request, post_id):
    post = Post.objects.get(id=post_id)
    Like.objects.get_or_create(user=request.user, post=post)
    return redirect('create_post')
