import cv2
import numpy as np
import csv
import os
import time

from ultralytics import YOLO
from centroid_tracker import CentroidTracker

# ---------- SETTINGS ----------
SOURCE = 0
MODEL_NAME = "yolov8n.pt"

TARGET_CLASSES = ["person"]

CONFIDENCE_THRESHOLD = 0.3

LINE_POSITION = 0.5

MAX_DISAPPEARED = 40
MAX_DISTANCE = 70

ALERT_THRESHOLD = 5
# --------------------------------


def filter_boxes_by_classes(results, model, classes_target):

    boxes = []
    names = []

    if results.boxes is None:
        return boxes, names

    for box in results.boxes:

        conf = float(box.conf[0])

        if conf < CONFIDENCE_THRESHOLD:
            continue

        cls_idx = int(box.cls[0])
        cls_name = model.names[cls_idx]

        accept = False

        if classes_target is None:
            accept = True

        else:
            if cls_name in classes_target:
                accept = True

        if accept:
            x1, y1, x2, y2 = map(int, box.xyxy[0])

            boxes.append((x1, y1, x2, y2))
            names.append(cls_name)

    return boxes, names


def main():

    print("[INFO] Loading model...")
    model = YOLO(MODEL_NAME)

    print("[INFO] Opening camera...")
    cap = cv2.VideoCapture(SOURCE)

    if not cap.isOpened():
        print("[ERROR] Camera not found")
        return

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    line_y = int(height * LINE_POSITION)

    tracker = CentroidTracker(
        max_disappeared=MAX_DISAPPEARED,
        max_distance=MAX_DISTANCE
    )

    counted_ids = set()

    count_in = 0
    count_out = 0

    log_file = "logs.csv"

    if not os.path.exists(log_file):
        with open(log_file, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["time", "in", "out"])

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        results = model(frame)[0]

        boxes, names = filter_boxes_by_classes(
            results,
            model,
            TARGET_CLASSES
        )

        objects = tracker.update(boxes)

        current_inside = 0

        cv2.line(frame, (0, line_y), (width, line_y), (0, 0, 255), 2)

        centroid_to_box = {}

        for i, (x1, y1, x2, y2) in enumerate(boxes):

            cX = int((x1 + x2) / 2.0)
            cY = int((y1 + y2) / 2.0)

            centroid_to_box[(cX, cY)] = i

        for oid, centroid in objects.items():

            cX, cY = centroid

            if cY > line_y:
                current_inside += 1

            if (cX, cY) in centroid_to_box:

                bi = centroid_to_box[(cX, cY)]

                x1, y1, x2, y2 = boxes[bi]

                cv2.rectangle(
                    frame,
                    (x1, y1),
                    (x2, y2),
                    (0, 255, 0),
                    2
                )

                cv2.putText(
                    frame,
                    f"Person",
                    (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 0),
                    2
                )

            cv2.circle(frame, (cX, cY), 4, (255, 0, 0), -1)

            cv2.putText(
                frame,
                f"ID {oid}",
                (cX - 10, cY - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 0, 0),
                2
            )

            history = tracker.get_history(oid)

            if len(history) >= 2 and oid not in counted_ids:

                prev_y = history[-2][1]
                curr_y = history[-1][1]

                # IN
                if prev_y < line_y and curr_y >= line_y:

                    count_in += 1

                    counted_ids.add(oid)

                    cv2.imwrite(
                        f"events/in_{time.time()}.jpg",
                        frame
                    )

                    with open(log_file, "a", newline="") as f:
                        writer = csv.writer(f)

                        writer.writerow([
                            time.strftime("%H:%M:%S"),
                            count_in,
                            count_out
                        ])

                # OUT
                elif prev_y > line_y and curr_y <= line_y:

                    count_out += 1

                    counted_ids.add(oid)

                    cv2.imwrite(
                        f"events/out_{time.time()}.jpg",
                        frame
                    )

                    with open(log_file, "a", newline="") as f:
                        writer = csv.writer(f)

                        writer.writerow([
                            time.strftime("%H:%M:%S"),
                            count_in,
                            count_out
                        ])

        cv2.putText(
            frame,
            f"IN: {count_in}",
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )

        cv2.putText(
            frame,
            f"OUT: {count_out}",
            (10, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )

        cv2.putText(
            frame,
            f"TOTAL: {count_in - count_out}",
            (10, 90),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"INSIDE: {current_inside}",
            (10, 120),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (255, 255, 0),
            2
        )

        # ALERT
        if current_inside >= ALERT_THRESHOLD:

            cv2.putText(
                frame,
                "ALERT: TOO MANY PEOPLE",
                (200, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                3
            )

        cv2.putText(
            frame,
            "[Q] Quit",
            (10, height - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (200, 200, 200),
            1
        )

        cv2.imshow("Smart Vision Analytics System", frame)

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

    print("[INFO] Program finished")


if __name__ == "__main__":
    main()